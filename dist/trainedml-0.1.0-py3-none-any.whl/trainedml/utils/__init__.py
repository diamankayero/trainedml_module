"""
Permet d'importer les utilitaires trainedml, dont get_model.
"""

from trainedml.models.factory import get_model