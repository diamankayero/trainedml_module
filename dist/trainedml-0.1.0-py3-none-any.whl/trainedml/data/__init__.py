"""
Module d'abstraction pour le sous-package data de trainedml.
Permet d'importer facilement les fonctions de chargement de données.
"""

from .loader import DataLoader
